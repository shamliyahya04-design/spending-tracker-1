"use client";

import dynamic from "next/dynamic";
import type { ComponentProps } from "react";

function ChartLoader() {
  return (
    <div className="flex h-full min-h-[240px] w-full items-center justify-center">
      <div className="size-full animate-pulse rounded-xl bg-muted/40" />
    </div>
  );
}

/**
 * Lazy-loaded chart wrappers. Deferring Recharts into a separate chunk
 * (ssr: false) keeps it out of the initial JS bundle and improves first paint.
 */
export const AreaTrendChart = dynamic<
  ComponentProps<typeof import("./area-trend").AreaTrendChart>
>(() => import("./area-trend").then((m) => m.AreaTrendChart), {
  ssr: false,
  loading: () => <ChartLoader />,
});

export const IncomeExpenseChart = dynamic<
  ComponentProps<typeof import("./income-expense-chart").IncomeExpenseChart>
>(() => import("./income-expense-chart").then((m) => m.IncomeExpenseChart), {
  ssr: false,
  loading: () => <ChartLoader />,
});

export const CategoryPieChart = dynamic<
  ComponentProps<typeof import("./category-pie").CategoryPieChart>
>(() => import("./category-pie").then((m) => m.CategoryPieChart), {
  ssr: false,
  loading: () => <ChartLoader />,
});

export const WeeklyBarChart = dynamic<
  ComponentProps<typeof import("./weekly-bar").WeeklyBarChart>
>(() => import("./weekly-bar").then((m) => m.WeeklyBarChart), {
  ssr: false,
  loading: () => <ChartLoader />,
});
