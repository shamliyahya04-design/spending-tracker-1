import { describe, it, expect } from "vitest";
import {
  cn,
  percentChange,
  clamp,
  uid,
  sparklineValues,
  initials,
  formatCurrency,
} from "@/lib/utils";

describe("cn (class merge)", () => {
  it("merges class names", () => {
    expect(cn("a", "b")).toBe("a b");
  });
  it("resolves conditional classes", () => {
    expect(cn("a", false && "b", undefined, "c")).toBe("a c");
  });
  it("dedupes conflicting tailwind utilities", () => {
    expect(cn("p-2", "p-4")).toBe("p-4");
  });
});

describe("percentChange", () => {
  it("computes increase", () => {
    expect(percentChange(150, 100)).toBe(50);
  });
  it("computes decrease", () => {
    expect(percentChange(50, 100)).toBe(-50);
  });
  it("returns 0 when both zero", () => {
    expect(percentChange(0, 0)).toBe(0);
  });
  it("returns null when previous is 0 but current is not", () => {
    expect(percentChange(100, 0)).toBeNull();
  });
});

describe("clamp", () => {
  it("clamps below min", () => {
    expect(clamp(-5, 0, 10)).toBe(0);
  });
  it("clamps above max", () => {
    expect(clamp(99, 0, 10)).toBe(10);
  });
  it("passes value within range", () => {
    expect(clamp(5, 0, 10)).toBe(5);
  });
});

describe("uid", () => {
  it("generates unique ids with prefix", () => {
    const a = uid("tx");
    const b = uid("tx");
    expect(a).not.toBe(b);
    expect(a.startsWith("tx_")).toBe(true);
  });
});

describe("sparklineValues", () => {
  it("returns the requested number of points", () => {
    expect(sparklineValues(1, 10).length).toBe(10);
  });
  it("stays above the floor", () => {
    const vals = sparklineValues(7, 20, 100);
    expect(Math.min(...vals)).toBeGreaterThanOrEqual(100 * 0.3);
  });
});

describe("initials", () => {
  it("extracts first letters", () => {
    expect(initials("Alex Morgan")).toBe("AM");
  });
  it("handles single word", () => {
    expect(initials("Ahmed")).toBe("A");
  });
});

describe("formatCurrency", () => {
  it("formats USD with symbol", () => {
    expect(formatCurrency(1234.5, "USD")).toContain("1,234.50");
    expect(formatCurrency(1234.5, "USD")).toContain("$");
  });
  it("shows sign when requested", () => {
    expect(formatCurrency(50, "USD", { showSign: true })).toMatch(/^\+/);
    expect(formatCurrency(-50, "USD")).toMatch(/^-/);
  });
  it("JPY has no decimals", () => {
    expect(formatCurrency(1000, "JPY")).not.toContain(".00");
  });
  it("compact mode shortens thousands", () => {
    expect(formatCurrency(1500, "USD", { compact: true })).toContain("K");
  });
});
