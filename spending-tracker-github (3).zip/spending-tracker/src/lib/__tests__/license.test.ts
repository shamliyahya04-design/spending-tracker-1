// @vitest-environment node
import { describe, it, expect, beforeAll } from "vitest";
import nacl from "tweetnacl";
import { verifyLicense, type LicenseType } from "@/lib/license";
import {
  bytesToHex,
  hexToBytes,
  utf8ToBytes,
  bytesToUtf8,
} from "@/lib/crypto";

/**
 * Generates a license key string identical to scripts/license-tool.mjs,
 * so we can exercise verifyLicense end-to-end with our own keypair.
 */
function issue(
  kp: nacl.SignKeyPair,
  opts: { id: string; type: LicenseType; issued: number; expires: number; device?: string; name?: string }
) {
  const payload = [
    "v1",
    opts.id,
    opts.type,
    opts.issued,
    opts.expires,
    opts.device ?? "",
    opts.name ?? "",
  ].join("|");
  const sig = nacl.sign.detached(utf8ToBytes(payload), kp.secretKey);
  return bytesToHex(utf8ToBytes(payload)) + "." + bytesToHex(sig);
}

describe("license verification", () => {
  let kp: nacl.SignKeyPair;
  let pubHex: string;

  beforeAll(() => {
    kp = nacl.sign.keyPair();
    pubHex = bytesToHex(kp.publicKey);
  });

  it("accepts a properly signed key", () => {
    const key = issue(kp, {
      id: "LIC-1",
      type: "pro",
      issued: 1000,
      expires: 0,
    });
    const info = verifyLicense(key, undefined, pubHex);
    expect(info.valid).toBe(true);
    expect(info.id).toBe("LIC-1");
    expect(info.type).toBe("pro");
  });

  it("rejects a tampered payload", () => {
    const key = issue(kp, {
      id: "LIC-2",
      type: "pro",
      issued: 1000,
      expires: 0,
    });
    // Flip a character in the payload half
    const tampered = "0" + key.slice(1);
    const info = verifyLicense(tampered, undefined, pubHex);
    expect(info.valid).toBe(false);
    expect(info.reason).toMatch(/signature|format/);
  });

  it("rejects a key verified with the wrong public key", () => {
    const key = issue(kp, {
      id: "LIC-3",
      type: "pro",
      issued: 1000,
      expires: 0,
    });
    const other = nacl.sign.keyPair();
    const info = verifyLicense(key, undefined, bytesToHex(other.publicKey));
    expect(info.valid).toBe(false);
    expect(info.reason).toBe("bad_signature");
  });

  it("rejects an expired key", () => {
    const key = issue(kp, {
      id: "LIC-4",
      type: "pro",
      issued: 0,
      expires: 1, // 1970
    });
    const info = verifyLicense(key, undefined, pubHex);
    expect(info.valid).toBe(false);
    expect(info.reason).toBe("expired");
  });

  it("lifetime keys (expires 0) never expire", () => {
    const key = issue(kp, {
      id: "LIC-5",
      type: "lifetime",
      issued: 0,
      expires: 0,
    });
    const info = verifyLicense(key, undefined, pubHex);
    expect(info.valid).toBe(true);
  });

  it("enforces device binding", () => {
    const key = issue(kp, {
      id: "LIC-6",
      type: "pro",
      issued: 1000,
      expires: 0,
      device: "DEVICE-A",
    });
    expect(verifyLicense(key, "DEVICE-A", pubHex).valid).toBe(true);
    expect(verifyLicense(key, "DEVICE-B", pubHex).valid).toBe(false);
    expect(verifyLicense(key, "DEVICE-B", pubHex).reason).toBe("device_mismatch");
  });

  it("rejects malformed input", () => {
    expect(verifyLicense("garbage", undefined, pubHex).valid).toBe(false);
    expect(verifyLicense("", undefined, pubHex).valid).toBe(false);
  });
});

describe("crypto helpers round-trip", () => {
  it("hex <-> bytes", () => {
    const original = utf8ToBytes("Spending Tracker € 中 مرحبا");
    const hex = bytesToHex(original);
    const back = hexToBytes(hex);
    expect(bytesToUtf8(back)).toBe("Spending Tracker € 中 مرحبا");
  });
});
