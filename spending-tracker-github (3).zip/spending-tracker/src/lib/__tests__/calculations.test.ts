import { describe, it, expect } from "vitest";
import {
  summarize,
  inRange,
  categoryBreakdown,
  budgetStatuses,
  monthlySeries,
} from "@/lib/calculations";
import { DEFAULT_CATEGORIES } from "@/lib/constants";
import type { Transaction, Budget } from "@/lib/types";

const today = new Date();
const iso = (d: Date) => d.toISOString().slice(0, 10);

function tx(
  over: Partial<Transaction> & { amount: number; type: "income" | "expense" }
): Transaction {
  return {
    id: `tx_${Math.random()}`,
    currency: "USD",
    categoryId: over.type === "income" ? "cat_salary" : "cat_food",
    date: iso(today),
    time: "12:00",
    merchant: "Test",
    paymentMethod: "card",
    tags: [],
    status: "completed",
    recurrence: "none",
    createdAt: today.toISOString(),
    ...over,
  } as Transaction;
}

describe("summarize", () => {
  it("sums income and expenses", () => {
    const s = summarize([
      tx({ amount: 1000, type: "income" }),
      tx({ amount: 300, type: "expense" }),
      tx({ amount: 200, type: "expense" }),
    ]);
    expect(s.income).toBe(1000);
    expect(s.expenses).toBe(500);
    expect(s.balance).toBe(500);
    expect(s.savingsRate).toBe(50);
  });

  it("ignores failed transactions", () => {
    const s = summarize([
      tx({ amount: 1000, type: "income" }),
      tx({ amount: 300, type: "expense", status: "failed" }),
    ]);
    expect(s.expenses).toBe(0);
    expect(s.balance).toBe(1000);
  });

  it("handles empty input", () => {
    const s = summarize([]);
    expect(s.income).toBe(0);
    expect(s.savingsRate).toBe(0);
  });
});

describe("inRange", () => {
  it("filters by date interval", () => {
    const old = tx({ amount: 10, type: "expense", date: "2020-01-01" });
    const day = iso(today);
    const recent = tx({ amount: 10, type: "expense", date: day });
    const dayStart = new Date(`${day}T00:00:00`);
    const dayEnd = new Date(`${day}T23:59:59`);
    const result = inRange([old, recent], dayStart, dayEnd);
    expect(result).toHaveLength(1);
    expect(result[0]).toBe(recent);
  });
});

describe("categoryBreakdown", () => {
  it("computes percentages summing to 100", () => {
    const breakdown = categoryBreakdown(
      [
        tx({ amount: 300, type: "expense", categoryId: "cat_food" }),
        tx({ amount: 100, type: "expense", categoryId: "cat_transport" }),
      ],
      DEFAULT_CATEGORIES,
      "USD"
    );
    expect(breakdown).toHaveLength(2);
    expect(breakdown[0]!.total).toBe(300); // sorted desc
    const totalPct = breakdown.reduce((s, b) => s + b.percentage, 0);
    expect(totalPct).toBeCloseTo(100, 5);
  });

  it("ignores income transactions", () => {
    const breakdown = categoryBreakdown(
      [tx({ amount: 500, type: "income" })],
      DEFAULT_CATEGORIES,
      "USD"
    );
    expect(breakdown).toHaveLength(0);
  });
});

describe("budgetStatuses", () => {
  it("flags exceeded budgets", () => {
    const budgets: Budget[] = [
      {
        id: "b1",
        name: "Food",
        amount: 100,
        period: "monthly",
        categoryId: "cat_food",
        createdAt: today.toISOString(),
      },
    ];
    const txs = [tx({ amount: 150, type: "expense", categoryId: "cat_food" })];
    const statuses = budgetStatuses(budgets, txs, "USD");
    expect(statuses[0]!.status).toBe("exceeded");
    expect(statuses[0]!.percentage).toBe(150);
  });

  it("flags warning near 80%", () => {
    const budgets: Budget[] = [
      {
        id: "b1",
        name: "Food",
        amount: 100,
        period: "monthly",
        categoryId: "cat_food",
        createdAt: today.toISOString(),
      },
    ];
    const txs = [tx({ amount: 85, type: "expense", categoryId: "cat_food" })];
    const statuses = budgetStatuses(budgets, txs, "USD");
    expect(statuses[0]!.status).toBe("warning");
  });
});

describe("monthlySeries", () => {
  it("returns one bucket per month", () => {
    const series = monthlySeries([], 6);
    expect(series).toHaveLength(6);
    expect(series[0]).toHaveProperty("income");
    expect(series[0]).toHaveProperty("expenses");
    expect(series[0]).toHaveProperty("net");
  });
});
