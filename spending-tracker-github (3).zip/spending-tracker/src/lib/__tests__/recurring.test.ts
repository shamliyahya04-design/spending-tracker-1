import { describe, it, expect } from "vitest";
import { generateDueInstances, nextOccurrence } from "@/lib/recurring";
import type { Transaction } from "@/lib/types";

const now = new Date("2026-07-31T12:00:00Z");

function tpl(over: Partial<Transaction>): Transaction {
  return {
    id: "tpl1",
    currency: "USD",
    categoryId: "cat_rent",
    date: "2026-01-05",
    time: "09:00",
    merchant: "Landlord",
    paymentMethod: "bank_transfer",
    tags: [],
    status: "completed",
    recurrence: "monthly",
    createdAt: "2026-01-05T00:00:00Z",
    amount: 900,
    type: "expense",
    ...over,
  } as Transaction;
}

describe("nextOccurrence", () => {
  const d = new Date("2026-01-15");
  it("daily +1 day", () => {
    expect(nextOccurrence(d, "daily").getDate()).toBe(16);
  });
  it("weekly +7 days", () => {
    expect(nextOccurrence(d, "weekly").getDate()).toBe(22);
  });
  it("monthly +1 month", () => {
    expect(nextOccurrence(d, "monthly").getMonth()).toBe(1); // Feb
  });
});

describe("generateDueInstances", () => {
  it("generates missing monthly occurrences up to now", () => {
    const due = generateDueInstances([tpl({})], now);
    // Template is Jan 5 monthly; due: Feb, Mar, Apr, May, Jun, Jul = 6
    expect(due.length).toBe(6);
    // Each generated instance is concrete (no recurrence) and linked to template
    for (const d of due) {
      expect(d.recurringParentId).toBe("tpl1");
      expect(d.recurrence).toBe("none");
    }
  });

  it("does not regenerate existing occurrences", () => {
    const template = tpl({});
    const already = { ...template, id: "tx_x", recurringParentId: "tpl1", recurrence: "none" as const, date: "2026-02-05" };
    const due = generateDueInstances([template, already], now);
    const febExists = due.some((d) => d.date === "2026-02-05");
    expect(febExists).toBe(false);
    expect(due.length).toBe(5); // Mar..Jul
  });

  it("ignores one-time transactions", () => {
    const oneOff = tpl({ recurrence: "none" });
    expect(generateDueInstances([oneOff], now)).toHaveLength(0);
  });

  it("skips future-dated templates", () => {
    const future = tpl({ date: "2026-12-01" });
    expect(generateDueInstances([future], now)).toHaveLength(0);
  });
});
