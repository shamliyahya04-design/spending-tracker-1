import { describe, it, expect } from "vitest";
import type { CurrencyCode } from "@/lib/types";
import {
  CURRENCIES,
  convertFromUSD,
  convertCurrency,
  getCurrency,
  CURRENCY_LIST,
} from "@/lib/currencies";

describe("currency registry", () => {
  it("exposes all 7 currencies", () => {
    expect(CURRENCY_LIST.length).toBe(7);
  });
  it("USD is the base (rate 1)", () => {
    expect(CURRENCIES.USD.rateFromUSD).toBe(1);
  });
  it("getCurrency falls back to USD for unknown code", () => {
    expect(getCurrency("XYZ" as unknown as CurrencyCode).code).toBe("USD");
  });
});

describe("convertFromUSD", () => {
  it("returns the same amount for USD", () => {
    expect(convertFromUSD(100, "USD")).toBe(100);
  });
  it("converts to SAR at 3.75", () => {
    expect(convertFromUSD(100, "SAR")).toBe(375);
  });
  it("respects target decimals", () => {
    expect(convertFromUSD(100, "JPY")).toBe(15600); // 0 decimals
  });
});

describe("convertCurrency", () => {
  it("converts across currencies via USD base", () => {
    // 100 USD -> 375 SAR
    expect(convertCurrency(100, "USD", "SAR")).toBe(375);
  });
  it("round-trips back near original", () => {
    const sar = convertCurrency(100, "USD", "SAR");
    const back = convertCurrency(sar, "SAR", "USD");
    expect(back).toBeCloseTo(100, 1);
  });
});
