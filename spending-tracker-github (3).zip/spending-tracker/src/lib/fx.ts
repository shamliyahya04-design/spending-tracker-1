import { CURRENCIES, setLiveRates } from "./currencies";
import type { CurrencyCode } from "./types";

/**
 * Live FX rate service.
 * - Fetches USD-relative rates from a free, key-less endpoint.
 * - Caches in localStorage for 24h to minimize requests.
 * - Falls back to static demo rates on any failure (offline-friendly).
 */

const CACHE_KEY = "st-fx-cache";
const TTL = 24 * 60 * 60 * 1000; // 1 day
const ENDPOINT = "https://open.er-api.com/v6/latest/USD";

interface FxCache {
  ts: number;
  rates: Record<string, number>;
}

function readCache(): FxCache | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as FxCache;
    if (Date.now() - parsed.ts > TTL) return null;
    return parsed;
  } catch {
    return null;
  }
}

function writeCache(cache: FxCache) {
  if (typeof localStorage === "undefined") return;
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
  } catch {
    /* storage full / unavailable */
  }
}

function pickSupported(
  apiRates: Record<string, number>
): Partial<Record<CurrencyCode, number>> {
  const out: Partial<Record<CurrencyCode, number>> = {};
  for (const code of Object.keys(CURRENCIES) as CurrencyCode[]) {
    const r = apiRates[code];
    if (typeof r === "number" && Number.isFinite(r) && r > 0) {
      out[code] = r;
    }
  }
  return out;
}

/** Refresh exchange rates. Safe to call on app mount; never throws. */
export async function refreshFxRates(): Promise<void> {
  // 1) Apply cached rates immediately (instant, offline-ish)
  const cached = readCache();
  if (cached) setLiveRates(pickSupported(cached.rates));

  // 2) Fetch fresh rates in the background
  try {
    const res = await fetch(ENDPOINT, { cache: "no-store" });
    if (!res.ok) throw new Error(`FX HTTP ${res.status}`);
    const data = (await res.json()) as { rates?: Record<string, number> };
    if (!data.rates) throw new Error("FX payload missing rates");
    writeCache({ ts: Date.now(), rates: data.rates });
    setLiveRates(pickSupported(data.rates));
  } catch {
    // Keep whatever we have (cached or static fallback) — fail silently.
  }
}
