import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { format } from "date-fns";

import type { Transaction, Category } from "./types";

export interface ReportPdfData {
  title: string;
  rangeStart: Date;
  rangeEnd: Date;
  summary: {
    income: number;
    expenses: number;
    balance: number;
    savingsRate: number;
    currency: string;
  };
  transactions: Transaction[];
  categories: Category[];
  formatAmount: (n: number) => string;
}

/**
 * Generates a polished financial report PDF and triggers a download.
 * Runs fully client-side (works offline in the APK).
 */
export function generateReportPdf(data: ReportPdfData) {
  const {
    title,
    rangeStart,
    rangeEnd,
    summary,
    transactions,
    categories,
    formatAmount,
  } = data;

  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 40;

  // Header band
  doc.setFillColor(91, 91, 245); // primary indigo
  doc.rect(0, 0, pageWidth, 80, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.text(title, margin, 40);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.text(
    `${format(rangeStart, "d MMM yyyy")} — ${format(rangeEnd, "d MMM yyyy")}`,
    margin,
    60
  );

  // Summary cards
  doc.setTextColor(30, 30, 40);
  const stats = [
    { label: "Income", value: summary.income, color: [22, 163, 74] as const },
    { label: "Expenses", value: summary.expenses, color: [220, 38, 38] as const },
    {
      label: "Net",
      value: summary.balance,
      color: summary.balance >= 0 ? ([22, 163, 74] as const) : ([220, 38, 38] as const),
    },
  ];
  const cardW = (pageWidth - margin * 2 - 20) / 3;
  stats.forEach((s, i) => {
    const x = margin + i * (cardW + 10);
    doc.setFillColor(245, 247, 252);
    doc.roundedRect(x, 100, cardW, 60, 8, 8, "F");
    doc.setFontSize(9);
    doc.setTextColor(110, 110, 120);
    doc.text(s.label.toUpperCase(), x + 12, 120);
    doc.setFontSize(15);
    doc.setTextColor(s.color[0]!, s.color[1]!, s.color[2]!);
    doc.setFont("helvetica", "bold");
    doc.text(formatAmount(s.value), x + 12, 142);
    doc.setFont("helvetica", "normal");
  });

  // Savings rate line
  doc.setTextColor(110, 110, 120);
  doc.setFontSize(10);
  doc.text(
    `Savings rate: ${summary.savingsRate.toFixed(1)}%   ·   ${transactions.length} transactions`,
    margin,
    185
  );

  // Transactions table
  const body = transactions.map((t) => {
    const cat = categories.find((c) => c.id === t.categoryId);
    return [
      t.date,
      t.merchant,
      cat?.name ?? "—",
      t.type === "income" ? "Income" : "Expense",
      formatAmount(t.type === "income" ? t.amount : -t.amount),
    ];
  });

  autoTable(doc, {
    startY: 200,
    head: [["Date", "Merchant", "Category", "Type", "Amount"]],
    body,
    theme: "striped",
    headStyles: { fillColor: [91, 91, 245], fontSize: 9 },
    bodyStyles: { fontSize: 9, textColor: [40, 40, 50] },
    alternateRowStyles: { fillColor: [247, 249, 252] },
    margin: { left: margin, right: margin },
    didParseCell: (data) => {
      if (data.section === "body" && data.column.index === 4) {
        const txt = String(data.cell.raw);
        if (txt.startsWith("-")) data.cell.styles.textColor = [220, 38, 38];
        else data.cell.styles.textColor = [22, 163, 74];
      }
    },
  });

  // Footer
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 160);
    doc.text(
      `Generated ${format(new Date(), "d MMM yyyy, h:mm a")}   ·   Page ${i}/${pages}`,
      margin,
      doc.internal.pageSize.getHeight() - 20
    );
  }

  const stamp = `${format(rangeStart, "yyyyMMdd")}-${format(rangeEnd, "yyyyMMdd")}`;
  doc.save(`report-${stamp}.pdf`);
}
