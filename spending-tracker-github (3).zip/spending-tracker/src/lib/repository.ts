import type {
  AppNotification,
  Budget,
  Category,
  Goal,
  Settings,
  Transaction,
} from "./types";

/**
 * Data-access abstraction ("repository" pattern).
 *
 * The app currently uses a local repository backed by localStorage. To add
 * cloud sync later, implement `Repository` for your backend (e.g. Supabase,
 * Firebase) and return it from `getRepository()` when env vars are present.
 *
 * The shape (`DataSnapshot`) is identical to what the Zustand store persists,
 * so swapping the backend is a one-file change that touches no UI.
 */

export interface DataSnapshot {
  transactions: Transaction[];
  categories: Category[];
  budgets: Budget[];
  goals: Goal[];
  notifications: AppNotification[];
  settings: Settings;
}

export interface Repository {
  load(): Promise<DataSnapshot | null>;
  save(snapshot: DataSnapshot): Promise<void>;
  wipe(): Promise<void>;
}

const STORAGE_KEY = "spending-tracker-store";

export class LocalRepository implements Repository {
  async load(): Promise<DataSnapshot | null> {
    if (typeof localStorage === "undefined") return null;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      return (parsed.state ?? parsed) as DataSnapshot;
    } catch {
      return null;
    }
  }

  async save(snapshot: DataSnapshot): Promise<void> {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ state: snapshot, version: 1 })
    );
  }

  async wipe(): Promise<void> {
    if (typeof localStorage === "undefined") return;
    localStorage.removeItem(STORAGE_KEY);
  }
}

/**
 * Supabase adapter (drop-in once you add @supabase/supabase-js).
 * Configure NEXT_PUBLIC_SUPABASE_URL + NEXT_PUBLIC_SUPABASE_ANON_KEY, then
 * implement the three methods to read/write the snapshot as a JSON row
 * scoped to the authenticated user.
 */
export class SupabaseRepository implements Repository {
  constructor(
    private userId: string,
    private client: { from: (t: string) => unknown }
  ) {}

  async load(): Promise<DataSnapshot | null> {
    // const { data } = await (this.client.from("snapshots") as any)
    //   .select("data").eq("user_id", this.userId).single();
    // return data?.data ?? null;
    throw new Error("SupabaseRepository.load() not configured");
  }
  async save(_snapshot: DataSnapshot): Promise<void> {
    // await (this.client.from("snapshots") as any)
    //   .upsert({ user_id: this.userId, data: snapshot, updated_at: new Date().toISOString() });
    throw new Error("SupabaseRepository.save() not configured");
  }
  async wipe(): Promise<void> {
    throw new Error("SupabaseRepository.wipe() not configured");
  }
}

/** Resolve the active repository based on environment. */
export function getRepository(): Repository {
  // When cloud is configured, return a SupabaseRepository(auth.uid(), supabase).
  return new LocalRepository();
}
