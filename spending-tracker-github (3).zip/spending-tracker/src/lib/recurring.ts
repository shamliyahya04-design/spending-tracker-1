import {
  addDays,
  addMonths,
  addWeeks,
  addYears,
  format,
  isAfter,
  parseISO,
} from "date-fns";

import type { RecurrenceFrequency, Transaction } from "./types";
import { uid } from "./utils";

/** Advance a date by one recurrence period. */
export function nextOccurrence(date: Date, freq: RecurrenceFrequency): Date {
  switch (freq) {
    case "daily":
      return addDays(date, 1);
    case "weekly":
      return addWeeks(date, 1);
    case "monthly":
      return addMonths(date, 1);
    case "quarterly":
      return addMonths(date, 3);
    case "yearly":
      return addYears(date, 1);
    default:
      return date;
  }
}

/**
 * Compute recurring transaction instances that are due (up to `now`) but not
 * yet present. A "template" is any transaction with a recurrence and no parent.
 * Dedup is global on (merchant|type|date) so pre-seeded data isn't duplicated.
 */
export function generateDueInstances(
  transactions: Transaction[],
  now: Date = new Date()
): Transaction[] {
  const templates = transactions.filter(
    (t) => t.recurrence !== "none" && !t.recurringParentId
  );

  // Global occupancy set to avoid duplicates across templates & existing data.
  const occupied = new Set<string>();
  for (const t of transactions) {
    occupied.add(`${t.merchant}|${t.type}|${t.date}`);
  }

  const due: Transaction[] = [];
  const MAX_PER_TEMPLATE = 365; // safety cap (e.g. daily for a year)

  for (const tpl of templates) {
    let cursor = parseISO(tpl.date); // occurrence #0 is the template itself
    let count = 0;
    cursor = nextOccurrence(cursor, tpl.recurrence);

    while (!isAfter(cursor, now) && count < MAX_PER_TEMPLATE) {
      const isoDate = format(cursor, "yyyy-MM-dd");
      const key = `${tpl.merchant}|${tpl.type}|${isoDate}`;
      if (!occupied.has(key)) {
        occupied.add(key);
        due.push({
          ...tpl,
          id: uid("tx"),
          date: isoDate,
          recurringParentId: tpl.id,
          recurrence: "none", // generated instances are concrete
          createdAt: now.toISOString(),
          isFavorite: false,
          notes: tpl.notes || undefined,
        });
      }
      cursor = nextOccurrence(cursor, tpl.recurrence);
      count++;
    }
  }

  return due;
}
