"use client";

import * as React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Wallet2,
  Check,
  ChevronDown,
  ArrowLeft,
  MessageCircle,
  CreditCard,
  Moon,
  Sun,
  ShieldCheck,
  Zap,
  Star,
} from "lucide-react";

import { Icon } from "@/components/ui/icon";
import { salesConfig } from "@/lib/sales-config";
import { useI18n } from "@/lib/hooks";

function whatsappLink(message: string) {
  return `https://wa.me/${salesConfig.whatsapp}?text=${encodeURIComponent(message)}`;
}

export default function LandingPage() {
  const { language } = useI18n();
  const [dark, setDark] = React.useState(false);
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    setMounted(true);
    setDark(document.documentElement.classList.contains("dark"));
  }, []);
  const toggleTheme = () => {
    const isDark = document.documentElement.classList.toggle("dark");
    setDark(isDark);
  };

  const orderMsg =
    language === "ar"
      ? `مرحباً، أريد شراء تطبيق ${salesConfig.productName}`
      : `Hi, I'd like to buy ${salesConfig.productName}`;

  return (
    <div className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Ambient background */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-40 start-1/4 size-[600px] rounded-full bg-primary/15 blur-[130px]" />
        <div className="absolute bottom-0 end-0 size-[500px] rounded-full bg-chart-2/15 blur-[130px]" />
      </div>

      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/70 backdrop-blur-xl">
        <nav className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-2.5">
            <div className="flex size-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/70 text-primary-foreground shadow-glow">
              <Wallet2 className="size-5" />
            </div>
            <span className="font-display font-bold">{salesConfig.productName}</span>
          </div>
          <div className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <a href="#features" className="transition-colors hover:text-foreground">
              {language === "ar" ? "المميزات" : "Features"}
            </a>
            <a href="#pricing" className="transition-colors hover:text-foreground">
              {language === "ar" ? "الأسعار" : "Pricing"}
            </a>
            <a href="#faq" className="transition-colors hover:text-foreground">
              FAQ
            </a>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="flex size-9 items-center justify-center rounded-xl border border-border text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            >
              {mounted && dark ? <Sun className="size-4" /> : <Moon className="size-4" />}
            </button>
            <Link
              href="/"
              className="hidden rounded-xl border border-border px-3 py-2 text-sm font-medium transition-colors hover:bg-secondary sm:block"
            >
              {language === "ar" ? "فتح التطبيق" : "Open app"}
            </Link>
            <a
              href={whatsappLink(orderMsg)}
              target="_blank"
              rel="noreferrer"
              className="rounded-xl bg-gradient-to-br from-primary to-primary/80 px-4 py-2 text-sm font-semibold text-primary-foreground shadow-soft transition-opacity hover:opacity-90"
            >
              {language === "ar" ? "اشترِ الآن" : "Buy now"}
            </a>
          </div>
        </nav>
      </header>

      {/* Hero */}
      <section className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-3 py-1 text-xs text-muted-foreground">
            <Star className="size-3.5 fill-amber-400 text-amber-400" />
            {language === "ar"
              ? "تطبيق مالية بتصميم فاخر"
              : "Premium personal finance app"}
          </div>
          <h1 className="font-display text-4xl font-bold leading-tight tracking-tight sm:text-5xl lg:text-6xl">
            {language === "ar"
              ? "أموالك، بأناقة"
              : "Your money,"}{" "}
            <span className="bg-gradient-to-br from-primary to-chart-4 bg-clip-text text-transparent">
              {language === "ar" ? "ووضوح" : "beautifully"}
            </span>
          </h1>
          <p className="mt-5 max-w-md text-lg text-muted-foreground">
            {salesConfig.tagline}
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href={whatsappLink(orderMsg)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-primary to-primary/80 px-6 py-3 font-semibold text-primary-foreground shadow-glow transition-opacity hover:opacity-95"
            >
              <MessageCircle className="size-5" />
              {language === "ar" ? "اطلب عبر واتساب" : "Order via WhatsApp"}
            </a>
            <a
              href="#pricing"
              className="inline-flex items-center gap-2 rounded-xl border border-border px-6 py-3 font-medium transition-colors hover:bg-secondary"
            >
              {language === "ar" ? "عرض الأسعار" : "See pricing"}
              <ChevronDown className="size-4" />
            </a>
          </div>
          <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="size-4 text-positive" />
              {language === "ar" ? "خصوصية كاملة" : "100% private"}
            </span>
            <span className="flex items-center gap-1.5">
              <Zap className="size-4 text-chart-3" />
              {language === "ar" ? "يعمل بلا إنترنت" : "Works offline"}
            </span>
          </div>
        </motion.div>

        {/* Phone mockup */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="relative mx-auto"
        >
          <PhonePreview />
        </motion.div>
      </section>

      {/* Stats */}
      <section className="border-y border-border/60 bg-secondary/20">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-6 px-4 py-10 sm:px-6 lg:grid-cols-4">
          {salesConfig.stats.map((s, i) => (
            <div key={i} className="text-center">
              <p className="font-display text-3xl font-bold text-primary sm:text-4xl">
                {s.value}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
            {language === "ar" ? "كل ما تحتاجه لإدارة أموالك" : "Everything to manage your money"}
          </h2>
          <p className="mt-3 text-muted-foreground">
            {language === "ar"
              ? "مجموعة أدوات مالية متكاملة بتصميم احترافي"
              : "A complete finance toolkit, beautifully designed"}
          </p>
        </div>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {salesConfig.features.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: (i % 3) * 0.08 }}
              className="card-premium rounded-2xl p-6 transition-shadow hover:shadow-elevated"
            >
              <div className="mb-4 flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <Icon name={f.icon} className="size-5" />
              </div>
              <h3 className="font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="border-y border-border/60 bg-secondary/20">
        <div className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
          <h2 className="mb-12 text-center font-display text-3xl font-bold tracking-tight sm:text-4xl">
            {language === "ar" ? "كيف تحصل عليه؟" : "How to get it"}
          </h2>
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {[
              {
                n: "1",
                t: language === "ar" ? "اطلب وادفع" : "Order & pay",
                d:
                  language === "ar"
                    ? "تواصل معنا عبر واتساب أو ادفع عبر رابط الدفع."
                    : "Message us on WhatsApp or pay via the payment link.",
              },
              {
                n: "2",
                t: language === "ar" ? "استلم التطبيق" : "Receive the app",
                d:
                  language === "ar"
                    ? "نرسل لك ملف التطبيق (APK) ورقم الترخيص فوراً."
                    : "We send you the app file (APK) and your license key.",
              },
              {
                n: "3",
                t: language === "ar" ? "ثبّت وفعّل" : "Install & activate",
                d:
                  language === "ar"
                    ? "ثبّت التطبيق وأدخل رقم الترخيص لبدء الاستخدام."
                    : "Install it and enter your license key to get started.",
              },
            ].map((step) => (
              <div key={step.n} className="relative text-center">
                <div className="mx-auto mb-4 flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-primary/70 font-display text-xl font-bold text-primary-foreground shadow-glow">
                  {step.n}
                </div>
                <h3 className="font-semibold">{step.t}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{step.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="mx-auto mb-12 max-w-2xl text-center">
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
            {language === "ar" ? "سعر واحد، تدفعه مرة" : "One price, paid once"}
          </h2>
          <p className="mt-3 text-muted-foreground">
            {language === "ar"
              ? "بدون اشتراكات متجددة — تدفع مرة وتملكه للأبد"
              : "No recurring subscription — pay once, own it forever"}
          </p>
        </div>
        <div className="mx-auto grid max-w-4xl grid-cols-1 gap-5 md:grid-cols-3">
          {salesConfig.prices.map((p, i) => (
            <div
              key={i}
              className={`card-premium rounded-2xl p-6 ${
                i === 1 ? "ring-2 ring-primary" : ""
              }`}
            >
              {i === 1 && (
                <span className="mb-3 inline-block rounded-full bg-primary px-2.5 py-0.5 text-xs font-semibold text-primary-foreground">
                  {language === "ar" ? "الأكثر شيوعاً" : "Popular"}
                </span>
              )}
              <p className="text-sm font-medium text-muted-foreground">{p.note}</p>
              <p className="mt-2 font-display text-4xl font-bold">
                {p.symbol} {p.oneTime.toLocaleString()}
                <span className="ms-1 text-base font-normal text-muted-foreground">
                  {p.currency}
                </span>
              </p>
              <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
                {[
                  language === "ar" ? "تطبيق كامل بلا حدود" : "Full app, no limits",
                  language === "ar" ? "تحديثات مستقبلية" : "Future updates",
                  language === "ar" ? "دعم عبر واتساب" : "WhatsApp support",
                ].map((feat) => (
                  <li key={feat} className="flex items-center gap-2">
                    <Check className="size-4 text-positive" /> {feat}
                  </li>
                ))}
              </ul>
              <a
                href={whatsappLink(
                  `${orderMsg} (${p.currency} ${p.oneTime})`
                )}
                target="_blank"
                rel="noreferrer"
                className={`mt-6 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition-opacity hover:opacity-90 ${
                  i === 1
                    ? "bg-gradient-to-br from-primary to-primary/80 text-primary-foreground"
                    : "border border-border hover:bg-secondary"
                }`}
              >
                <MessageCircle className="size-4" />
                {language === "ar" ? "اطلب الآن" : "Order now"}
              </a>
            </div>
          ))}
        </div>

        {/* Payment links */}
        {(salesConfig.paymentLinks.stripe ||
          salesConfig.paymentLinks.moyasar ||
          salesConfig.paymentLinks.tap) && (
          <div className="mx-auto mt-8 flex max-w-4xl flex-wrap items-center justify-center gap-3">
            <span className="text-sm text-muted-foreground">
              {language === "ar" ? "أو ادفع مباشرة:" : "Or pay directly:"}
            </span>
            {salesConfig.paymentLinks.stripe && (
              <PaymentBtn href={salesConfig.paymentLinks.stripe} label="Stripe / Card" />
            )}
            {salesConfig.paymentLinks.moyasar && (
              <PaymentBtn href={salesConfig.paymentLinks.moyasar} label="مدى / Apple Pay" />
            )}
            {salesConfig.paymentLinks.tap && (
              <PaymentBtn href={salesConfig.paymentLinks.tap} label="Tap" />
            )}
          </div>
        )}
      </section>

      {/* FAQ */}
      <section id="faq" className="border-t border-border/60 bg-secondary/20">
        <div className="mx-auto max-w-3xl px-4 py-20 sm:px-6">
          <h2 className="mb-10 text-center font-display text-3xl font-bold tracking-tight sm:text-4xl">
            {language === "ar" ? "أسئلة شائعة" : "FAQ"}
          </h2>
          <div className="space-y-3">
            {salesConfig.faq.map((item, i) => (
              <FaqItem key={i} q={item.q} a={item.a} />
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl border border-primary/30 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-10 text-center sm:p-16">
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
            {language === "ar"
              ? "جاهز للسيطرة على أموالك؟"
              : "Ready to take control?"}
          </h2>
          <p className="mx-auto mt-3 max-w-md text-muted-foreground">
            {language === "ar"
              ? "اطلب تطبيقك الآن وابدأ تتبّع مصروفاتك خلال دقائق."
              : "Order now and start tracking your spending in minutes."}
          </p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <a
              href={whatsappLink(orderMsg)}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-primary to-primary/80 px-7 py-3 font-semibold text-primary-foreground shadow-glow transition-opacity hover:opacity-95"
            >
              <MessageCircle className="size-5" />
              {language === "ar" ? "تواصل عبر واتساب" : "Message on WhatsApp"}
            </a>
            <Link
              href="/"
              className="inline-flex items-center gap-2 rounded-xl border border-border px-7 py-3 font-medium transition-colors hover:bg-secondary"
            >
              {language === "ar" ? "جرّب التطبيق" : "Try the app"}
              <ArrowLeft className="size-4 rtl:rotate-180" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:px-6">
          <div className="flex items-center gap-2">
            <Wallet2 className="size-4 text-primary" />
            <span>© {new Date().getFullYear()} {salesConfig.productName}</span>
          </div>
          <div className="flex gap-4">
            <a href={`mailto:${salesConfig.email}`} className="hover:text-foreground">
              {salesConfig.email}
            </a>
            <a
              href={whatsappLink(orderMsg)}
              target="_blank"
              rel="noreferrer"
              className="hover:text-foreground"
            >
              WhatsApp
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function PaymentBtn({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      className="inline-flex items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-sm font-medium transition-colors hover:bg-secondary"
    >
      <CreditCard className="size-4" />
      {label}
    </a>
  );
}

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div className="card-premium overflow-hidden rounded-2xl">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex w-full items-center justify-between gap-4 p-5 text-start"
      >
        <span className="font-medium">{q}</span>
        <ChevronDown
          className={`size-5 shrink-0 text-muted-foreground transition-transform ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>
      {open && (
        <motion.p
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          className="px-5 pb-5 text-sm text-muted-foreground"
        >
          {a}
        </motion.p>
      )}
    </div>
  );
}

/** Stylized phone preview built from real design tokens. */
function PhonePreview() {
  return (
    <div className="relative mx-auto w-[280px]">
      <div className="absolute -inset-6 -z-10 rounded-[3rem] bg-gradient-to-br from-primary/20 to-chart-4/20 blur-2xl" />
      <div className="rounded-[2.5rem] border-[10px] border-foreground/90 bg-foreground/90 p-1 shadow-2xl">
        <div className="overflow-hidden rounded-[2rem] bg-background">
          {/* status bar */}
          <div className="flex items-center justify-between px-5 pt-3 text-[10px] text-muted-foreground">
            <span>9:41</span>
            <div className="mx-auto h-1.5 w-16 rounded-full bg-foreground/80" />
            <span>100%</span>
          </div>
          {/* content */}
          <div className="space-y-3 p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] text-muted-foreground">الرصيد</p>
                <p className="tabular text-lg font-bold">$8,420</p>
              </div>
              <div className="size-9 rounded-xl bg-primary/10" />
            </div>
            {/* cards */}
            <div className="grid grid-cols-2 gap-2">
              {[
                { l: "دخل", v: "+3,200", c: "text-positive" },
                { l: "مصروف", v: "-1,480", c: "text-foreground" },
              ].map((c) => (
                <div key={c.l} className="rounded-xl bg-secondary/60 p-2.5">
                  <p className="text-[9px] text-muted-foreground">{c.l}</p>
                  <p className={`tabular text-xs font-bold ${c.c}`}>{c.v}</p>
                </div>
              ))}
            </div>
            {/* mini chart */}
            <div className="rounded-xl bg-secondary/40 p-3">
              <div className="mb-2 flex items-end justify-between gap-1.5">
                {[40, 65, 35, 80, 55, 70, 45].map((h, i) => (
                  <motion.div
                    key={i}
                    initial={{ height: 0 }}
                    whileInView={{ height: `${h}%` }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05, duration: 0.4 }}
                    className={`w-full rounded-t ${
                      i === 3 ? "bg-primary" : "bg-primary/40"
                    }`}
                    style={{ height: `${h}%`, minHeight: 6 }}
                  />
                ))}
              </div>
              <p className="text-[9px] text-muted-foreground">المصروفات الأسبوعية</p>
            </div>
            {/* rows */}
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="size-7 rounded-lg bg-primary/10" />
                <div className="flex-1">
                  <div className="h-2 w-16 rounded bg-secondary" />
                  <div className="mt-1 h-1.5 w-10 rounded bg-secondary/60" />
                </div>
                <div className="h-2 w-8 rounded bg-secondary" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
