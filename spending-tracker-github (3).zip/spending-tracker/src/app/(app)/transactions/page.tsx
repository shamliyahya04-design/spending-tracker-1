"use client";

import * as React from "react";
import { useSearchParams } from "next/navigation";
import { Plus } from "lucide-react";

import { PageHeader } from "@/components/layout/page-header";
import { TransactionTable } from "@/components/transactions/transaction-table";
import { TransactionDialog } from "@/components/transactions/transaction-dialog";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/hooks";

function TransactionsContent() {
  const { t } = useI18n();
  const searchParams = useSearchParams();
  const [addOpen, setAddOpen] = React.useState(false);
  const query = searchParams.get("q") ?? undefined;

  return (
    <>
      <PageHeader
        title={t("transactions.title")}
        description={t("transactions.subtitle")}
      >
        <Button variant="gradient" onClick={() => setAddOpen(true)}>
          <Plus className="size-4" />
          <span className="hidden sm:inline">{t("transactions.add")}</span>
        </Button>
      </PageHeader>

      <TransactionTable initialQuery={query} />

      <TransactionDialog open={addOpen} onClose={() => setAddOpen(false)} />
    </>
  );
}

export default function TransactionsPage() {
  return (
    <React.Suspense fallback={null}>
      <TransactionsContent />
    </React.Suspense>
  );
}
