"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { motion } from "framer-motion";
import { differenceInCalendarDays, parseISO } from "date-fns";

import { PageHeader } from "@/components/layout/page-header";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog } from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { Icon } from "@/components/ui/icon";
import { GoalRing } from "@/components/goals/goal-ring";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/hooks";
import { cn, formatCurrency, clamp, todayISO } from "@/lib/utils";
import { goalSchema, type GoalFormValues } from "@/lib/validation";
import { CATEGORY_COLORS, CATEGORY_ICONS } from "@/lib/constants";
import type { Goal } from "@/lib/types";

export default function GoalsPage() {
  const { t } = useI18n();
  const goals = useStore((s) => s.goals);
  const currency = useStore((s) => s.settings.currency);
  const addGoal = useStore((s) => s.addGoal);
  const updateGoal = useStore((s) => s.updateGoal);
  const deleteGoal = useStore((s) => s.deleteGoal);
  const contribute = useStore((s) => s.contributeToGoal);

  const [open, setOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Goal | null>(null);
  const [contributing, setContributing] = React.useState<Goal | null>(null);
  const [amount, setAmount] = React.useState("");

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors },
  } = useForm<GoalFormValues>({ resolver: zodResolver(goalSchema) });

  const openCreate = () => {
    setEditing(null);
    reset({
      name: "",
      targetAmount: 0,
      deadline: "",
      color: "chart-1",
      icon: "Target",
    });
    setOpen(true);
  };
  const openEdit = (g: Goal) => {
    setEditing(g);
    reset({
      name: g.name,
      targetAmount: g.targetAmount,
      deadline: g.deadline ?? "",
      color: g.color,
      icon: g.icon,
    });
    setOpen(true);
  };

  const onSubmit = (values: GoalFormValues) => {
    const payload = {
      ...values,
      deadline: values.deadline || undefined,
      currentAmount: editing?.currentAmount ?? 0,
    };
    if (editing) updateGoal(editing.id, payload);
    else addGoal(payload);
    setOpen(false);
  };

  const doContribute = (positive: boolean) => {
    if (!contributing) return;
    const amt = Number(amount);
    if (Number.isFinite(amt) && amt !== 0) {
      contribute(contributing.id, positive ? amt : -amt);
    }
    setContributing(null);
    setAmount("");
  };

  return (
    <>
      <PageHeader title={t("goals.title")} description={t("goals.subtitle")}>
        <Button variant="gradient" onClick={openCreate}>
          <Plus className="size-4" />
          <span className="hidden sm:inline">{t("goals.add")}</span>
        </Button>
      </PageHeader>

      {goals.length === 0 ? (
        <EmptyState
          icon="Target"
          title={t("goals.empty")}
          description={t("goals.emptyHint")}
          action={
            <Button variant="gradient" onClick={openCreate}>
              <Plus className="size-4" />
              {t("goals.add")}
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {goals.map((g, i) => {
            const pct = clamp((g.currentAmount / g.targetAmount) * 100, 0, 100);
            const completed = pct >= 100;
            const daysLeft = g.deadline
              ? differenceInCalendarDays(parseISO(g.deadline), new Date())
              : null;
            return (
              <motion.div
                key={g.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="card-premium relative overflow-hidden rounded-2xl p-5"
              >
                <div
                  className="pointer-events-none absolute -end-8 -top-8 size-32 rounded-full opacity-20 blur-2xl"
                  style={{ backgroundColor: `hsl(var(--${g.color}))` }}
                />
                <div className="relative flex items-start justify-between">
                  <div
                    className="flex size-11 items-center justify-center rounded-xl"
                    style={{
                      backgroundColor: `hsl(var(--${g.color}) / 0.12)`,
                      color: `hsl(var(--${g.color}))`,
                    }}
                  >
                    <Icon name={g.icon} className="size-5" />
                  </div>
                  <div className="flex gap-0.5">
                    <button
                      onClick={() => openEdit(g)}
                      className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                      aria-label={t("common.edit")}
                    >
                      <Pencil className="size-4" />
                    </button>
                    <button
                      onClick={() => deleteGoal(g.id)}
                      className="rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      aria-label={t("common.delete")}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>

                <div className="relative mt-4 flex items-center gap-4">
                  <GoalRing percentage={pct} color={g.color} size={84} />
                  <div className="min-w-0">
                    <h3 className="truncate font-semibold">{g.name}</h3>
                    <p className="tabular mt-0.5 text-sm text-muted-foreground">
                      {formatCurrency(g.currentAmount, currency)} /{" "}
                      {formatCurrency(g.targetAmount, currency)}
                    </p>
                    <p className="mt-1 text-xs">
                      {completed ? (
                        <span className="font-medium text-positive">
                          {t("goals.completed")}
                        </span>
                      ) : daysLeft !== null ? (
                        <span
                          className={cn(
                            daysLeft < 0 ? "text-destructive" : "text-muted-foreground"
                          )}
                        >
                          {daysLeft < 0
                            ? t("goals.overdue")
                            : t("goals.daysLeft", { days: daysLeft })}
                        </span>
                      ) : null}
                    </p>
                  </div>
                </div>

                <div className="relative mt-4 flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => setContributing(g)}
                  >
                    {t("goals.contribute")}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      contribute(g.id, -Math.min(100, g.currentAmount));
                    }}
                  >
                    −
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Create/Edit dialog */}
      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? t("common.edit") : t("goals.add")}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>{t("field.name")}</Label>
            <Input {...register("name")} placeholder="e.g. Vacation" />
            {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>{t("field.target")}</Label>
              <Input type="number" step="0.01" {...register("targetAmount")} />
              {errors.targetAmount && (
                <p className="text-xs text-destructive">{errors.targetAmount.message}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>{t("field.deadline")}</Label>
              <Input type="date" min={todayISO()} {...register("deadline")} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>{t("field.icon")}</Label>
            <div className="flex flex-wrap gap-1.5">
              {CATEGORY_ICONS.slice(0, 12).map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setValue("icon", ic)}
                  className={cn(
                    "flex size-9 items-center justify-center rounded-lg border transition-colors",
                    watch("icon") === ic
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border text-muted-foreground hover:bg-secondary"
                  )}
                >
                  <Icon name={ic} className="size-4" />
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>{t("field.color")}</Label>
            <div className="flex gap-2">
              {CATEGORY_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setValue("color", c)}
                  className={cn(
                    "size-8 rounded-full ring-offset-2 ring-offset-background transition-all",
                    watch("color") === c && "ring-2 ring-ring"
                  )}
                  style={{ backgroundColor: `hsl(var(--${c}))` }}
                  aria-label={c}
                />
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" variant="gradient">
              {t("common.save")}
            </Button>
          </div>
        </form>
      </Dialog>

      {/* Contribute dialog */}
      <Dialog
        open={!!contributing}
        onClose={() => setContributing(null)}
        title={contributing ? contributing.name : ""}
      >
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>{t("goals.contribute")}</Label>
            <Input
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              autoFocus
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => doContribute(false)}>
              {t("goals.withdraw")}
            </Button>
            <Button variant="gradient" onClick={() => doContribute(true)}>
              {t("goals.contribute")}
            </Button>
          </div>
        </div>
      </Dialog>
    </>
  );
}
