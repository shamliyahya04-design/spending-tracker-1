"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { motion } from "framer-motion";

import { PageHeader } from "@/components/layout/page-header";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { EmptyState } from "@/components/ui/empty-state";
import { Icon } from "@/components/ui/icon";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/hooks";
import { cn, formatCurrency } from "@/lib/utils";
import { budgetSchema, type BudgetFormValues } from "@/lib/validation";
import { budgetStatuses } from "@/lib/calculations";
import type { Budget } from "@/lib/types";

export default function BudgetsPage() {
  const { t } = useI18n();
  const budgets = useStore((s) => s.budgets);
  const transactions = useStore((s) => s.transactions);
  const categories = useStore((s) => s.categories);
  const currency = useStore((s) => s.settings.currency);
  const addBudget = useStore((s) => s.addBudget);
  const updateBudget = useStore((s) => s.updateBudget);
  const deleteBudget = useStore((s) => s.deleteBudget);

  const [open, setOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Budget | null>(null);

  const statuses = React.useMemo(
    () => budgetStatuses(budgets, transactions, currency),
    [budgets, transactions, currency]
  );

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<BudgetFormValues>({ resolver: zodResolver(budgetSchema) });

  const openCreate = () => {
    setEditing(null);
    reset({ name: "", amount: 0, period: "monthly", categoryId: "" });
    setOpen(true);
  };
  const openEdit = (b: Budget) => {
    setEditing(b);
    reset({
      name: b.name,
      amount: b.amount,
      period: b.period,
      categoryId: b.categoryId ?? "",
    });
    setOpen(true);
  };

  const onSubmit = (values: BudgetFormValues) => {
    const payload = {
      ...values,
      categoryId: values.categoryId || undefined,
    };
    if (editing) updateBudget(editing.id, payload);
    else addBudget(payload);
    setOpen(false);
  };

  return (
    <>
      <PageHeader title={t("budgets.title")} description={t("budgets.subtitle")}>
        <Button variant="gradient" onClick={openCreate}>
          <Plus className="size-4" />
          <span className="hidden sm:inline">{t("budgets.add")}</span>
        </Button>
      </PageHeader>

      {statuses.length === 0 ? (
        <EmptyState
          icon="Wallet"
          title={t("budgets.empty")}
          description={t("budgets.emptyHint")}
          action={
            <Button variant="gradient" onClick={openCreate}>
              <Plus className="size-4" />
              {t("budgets.add")}
            </Button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {statuses.map((s, i) => {
            const cat = categories.find((c) => c.id === s.budget.categoryId);
            const indicator =
              s.status === "exceeded"
                ? "bg-destructive"
                : s.status === "warning"
                  ? "bg-amber-500"
                  : "bg-positive";
            const statusLabel =
              s.status === "exceeded"
                ? t("budgets.exceeded")
                : s.status === "warning"
                  ? t("budgets.warning")
                  : t("budgets.onTrack");
            return (
              <motion.div
                key={s.budget.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="card-premium rounded-2xl p-5"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="flex size-10 items-center justify-center rounded-xl"
                      style={{
                        backgroundColor: cat
                          ? `hsl(var(--${cat.color}) / 0.12)`
                          : "hsl(var(--primary) / 0.12)",
                        color: cat
                          ? `hsl(var(--${cat.color}))`
                          : "hsl(var(--primary))",
                      }}
                    >
                      <Icon name={cat?.icon ?? "Wallet"} className="size-5" />
                    </div>
                    <div>
                      <p className="font-medium">{s.budget.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {t(s.budget.period === "monthly" ? "budgets.monthly" : "budgets.weekly")}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-0.5">
                    <button
                      onClick={() => openEdit(s.budget)}
                      className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                      aria-label={t("common.edit")}
                    >
                      <Pencil className="size-4" />
                    </button>
                    <button
                      onClick={() => deleteBudget(s.budget.id)}
                      className="rounded-md p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      aria-label={t("common.delete")}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>

                <div className="mt-4 flex items-end justify-between">
                  <div>
                    <p className="tabular text-2xl font-semibold">
                      {formatCurrency(s.spent, currency)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {t("budgets.of")} {formatCurrency(s.amount, currency)}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "rounded-full px-2 py-0.5 text-xs font-medium",
                      s.status === "exceeded" && "bg-destructive/10 text-destructive",
                      s.status === "warning" &&
                        "bg-amber-500/15 text-amber-600 dark:text-amber-400",
                      s.status === "onTrack" && "bg-positive/10 text-positive"
                    )}
                  >
                    {statusLabel}
                  </span>
                </div>

                <div className="mt-3">
                  <Progress value={s.percentage} indicatorClassName={cn(indicator)} />
                  <div className="mt-1.5 flex justify-between text-xs text-muted-foreground">
                    <span className="tabular">{s.percentage.toFixed(0)}%</span>
                    <span className="tabular">
                      {t("budgets.remaining")}: {formatCurrency(Math.max(0, s.remaining), currency)}
                    </span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? t("common.edit") : t("budgets.add")}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>{t("field.name")}</Label>
            <Input {...register("name")} placeholder={t("budgets.global")} />
            {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>{t("field.budget")}</Label>
              <Input type="number" step="0.01" {...register("amount")} />
              {errors.amount && (
                <p className="text-xs text-destructive">{errors.amount.message}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>{t("field.period")}</Label>
              <Select {...register("period")}>
                <option value="monthly">{t("budgets.monthly")}</option>
                <option value="weekly">{t("budgets.weekly")}</option>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>{t("field.category")}</Label>
            <Select {...register("categoryId")}>
              <option value="">{t("budgets.global")}</option>
              {categories
                .filter((c) => c.type === "expense")
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
            </Select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" variant="gradient">
              {t("common.save")}
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}
