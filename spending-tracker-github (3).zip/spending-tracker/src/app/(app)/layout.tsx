import { AppShell } from "@/components/layout/app-shell";

/**
 * The gated application shell (sidebar + topbar + license gate).
 * Public marketing routes (e.g. /landing) live outside this group.
 */
export default function AppGroupLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <AppShell>{children}</AppShell>;
}
