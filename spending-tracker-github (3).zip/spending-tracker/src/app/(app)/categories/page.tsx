"use client";

import * as React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Plus, Pencil, Trash2 } from "lucide-react";

import { PageHeader } from "@/components/layout/page-header";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Dialog } from "@/components/ui/dialog";
import { Icon } from "@/components/ui/icon";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/hooks";
import { cn } from "@/lib/utils";
import { categorySchema, type CategoryFormValues } from "@/lib/validation";
import { CATEGORY_COLORS, CATEGORY_ICONS } from "@/lib/constants";
import type { Category, TransactionType } from "@/lib/types";

export default function CategoriesPage() {
  const { t } = useI18n();
  const categories = useStore((s) => s.categories);
  const transactions = useStore((s) => s.transactions);
  const addCategory = useStore((s) => s.addCategory);
  const updateCategory = useStore((s) => s.updateCategory);
  const deleteCategory = useStore((s) => s.deleteCategory);

  const [open, setOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Category | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    formState: { errors },
  } = useForm<CategoryFormValues>({ resolver: zodResolver(categorySchema) });

  const countFor = (id: string) =>
    transactions.filter((tx) => tx.categoryId === id).length;

  const openCreate = (type: TransactionType) => {
    setEditing(null);
    reset({ name: "", type, icon: "Circle", color: "chart-1" });
    setOpen(true);
  };
  const openEdit = (c: Category) => {
    setEditing(c);
    reset({ name: c.name, type: c.type, icon: c.icon, color: c.color });
    setOpen(true);
  };

  const onSubmit = (values: CategoryFormValues) => {
    if (editing) updateCategory(editing.id, values);
    else addCategory(values);
    setOpen(false);
  };

  const renderSection = (type: TransactionType) => {
    const items = categories
      .filter((c) => c.type === type)
      .sort((a, b) => a.order - b.order);
    return (
      <section className="mb-8">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            {t(type === "income" ? "categories.income" : "categories.expense")}
          </h2>
          <Button variant="ghost" size="sm" onClick={() => openCreate(type)}>
            <Plus className="size-4" />
            {t("categories.add")}
          </Button>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((c) => (
            <div
              key={c.id}
              className="card-premium flex items-center gap-3 rounded-2xl p-4"
            >
              <div
                className="flex size-10 items-center justify-center rounded-xl"
                style={{
                  backgroundColor: `hsl(var(--${c.color}) / 0.12)`,
                  color: `hsl(var(--${c.color}))`,
                }}
              >
                <Icon name={c.icon} className="size-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{c.name}</p>
                <p className="text-xs text-muted-foreground">
                  {countFor(c.id)} {t("transactions.rowCount", { count: countFor(c.id) })}
                </p>
              </div>
              <div className="flex gap-0.5">
                <button
                  onClick={() => openEdit(c)}
                  className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                  aria-label={t("common.edit")}
                >
                  <Pencil className="size-4" />
                </button>
                <button
                  onClick={() =>
                    c.isDefault ? undefined : deleteCategory(c.id)
                  }
                  disabled={c.isDefault}
                  className={cn(
                    "rounded-md p-1.5 transition-colors",
                    c.isDefault
                      ? "cursor-not-allowed text-muted-foreground/30"
                      : "text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  )}
                  title={c.isDefault ? t("categories.deleteDefault") : t("common.delete")}
                  aria-label={t("common.delete")}
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  };

  return (
    <>
      <PageHeader title={t("categories.title")} description={t("categories.subtitle")} />

      {renderSection("income")}
      {renderSection("expense")}

      <Dialog
        open={open}
        onClose={() => setOpen(false)}
        title={editing ? t("common.edit") : t("categories.add")}
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>{t("field.name")}</Label>
            <Input {...register("name")} placeholder="e.g. Hobbies" />
            {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
          </div>
          {!editing && (
            <div className="space-y-1.5">
              <Label>{t("field.type")}</Label>
              <Select {...register("type")}>
                <option value="expense">{t("categories.expense")}</option>
                <option value="income">{t("categories.income")}</option>
              </Select>
            </div>
          )}
          <div className="space-y-1.5">
            <Label>{t("field.icon")}</Label>
            <div className="grid grid-cols-6 gap-1.5">
              {CATEGORY_ICONS.slice(0, 18).map((ic) => (
                <button
                  key={ic}
                  type="button"
                  onClick={() => setValue("icon", ic)}
                  className={cn(
                    "flex size-9 items-center justify-center rounded-lg border transition-colors",
                    watch("icon") === ic
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border text-muted-foreground hover:bg-secondary"
                  )}
                >
                  <Icon name={ic} className="size-4" />
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>{t("field.color")}</Label>
            <div className="flex gap-2">
              {CATEGORY_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setValue("color", c)}
                  className={cn(
                    "size-8 rounded-full ring-offset-2 ring-offset-background transition-all",
                    watch("color") === c && "ring-2 ring-ring"
                  )}
                  style={{ backgroundColor: `hsl(var(--${c}))` }}
                  aria-label={c}
                />
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              {t("common.cancel")}
            </Button>
            <Button type="submit" variant="gradient">
              {t("common.save")}
            </Button>
          </div>
        </form>
      </Dialog>
    </>
  );
}
