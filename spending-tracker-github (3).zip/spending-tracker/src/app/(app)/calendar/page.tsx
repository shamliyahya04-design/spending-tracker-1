"use client";

import * as React from "react";
import {
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  parseISO,
  startOfMonth,
  startOfWeek,
  subMonths,
} from "date-fns";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

import { PageHeader } from "@/components/layout/page-header";
import { Button } from "@/components/ui/button";
import { TransactionRow } from "@/components/transactions/transaction-row";
import { EmptyState } from "@/components/ui/empty-state";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/hooks";
import { cn, formatCurrency } from "@/lib/utils";
import { spendingByDay } from "@/lib/calculations";

export default function CalendarPage() {
  const { t, language } = useI18n();
  const transactions = useStore((s) => s.transactions);
  const currency = useStore((s) => s.settings.currency);

  const [cursor, setCursor] = React.useState(new Date());
  const [selectedDay, setSelectedDay] = React.useState<string | null>(
    format(new Date(), "yyyy-MM-dd")
  );

  const byDay = React.useMemo(() => spendingByDay(transactions), [transactions]);

  const monthStart = startOfMonth(cursor);
  const monthEnd = endOfMonth(cursor);
  const gridStart = startOfWeek(monthStart, { weekStartsOn: language === "ar" ? 6 : 1 });
  const gridEnd = endOfWeek(monthEnd, { weekStartsOn: language === "ar" ? 6 : 1 });
  const days = eachDayOfInterval({ start: gridStart, end: gridEnd });

  const weekDays =
    language === "ar"
      ? ["سبت", "أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة"]
      : ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  // Find max spending in month for heat intensity
  const monthMax = Math.max(
    1,
    ...days
      .filter((d) => isSameMonth(d, cursor))
      .map((d) => byDay[format(d, "yyyy-MM-dd")]?.expenses ?? 0)
  );

  const selectedTx = selectedDay
    ? transactions.filter((tx) => tx.date === selectedDay)
    : [];
  const selectedInfo = selectedDay ? byDay[selectedDay] : undefined;

  return (
    <>
      <PageHeader title={t("calendar.title")} description={t("calendar.subtitle")} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Calendar grid */}
        <div className="card-premium rounded-2xl p-4 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-lg font-semibold capitalize">
              {format(cursor, "MMMM yyyy", {
                locale: undefined,
              })}
            </h2>
            <div className="flex gap-1">
              <Button
                variant="outline"
                size="icon-sm"
                onClick={() => setCursor((c) => subMonths(c, 1))}
                aria-label="Previous month"
              >
                <ChevronLeft className="size-4 rtl:rotate-180" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setCursor(new Date());
                  setSelectedDay(format(new Date(), "yyyy-MM-dd"));
                }}
              >
                {t("reports.thisMonth")}
              </Button>
              <Button
                variant="outline"
                size="icon-sm"
                onClick={() => setCursor((c) => addMonths(c, 1))}
                aria-label="Next month"
              >
                <ChevronRight className="size-4 rtl:rotate-180" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {weekDays.map((d) => (
              <div
                key={d}
                className="pb-2 text-center text-xs font-medium text-muted-foreground"
              >
                {d}
              </div>
            ))}
            {days.map((day) => {
              const iso = format(day, "yyyy-MM-dd");
              const info = byDay[iso];
              const inMonth = isSameMonth(day, cursor);
              const isToday = isSameDay(day, new Date());
              const isSelected = selectedDay === iso;
              const intensity = info ? info.expenses / monthMax : 0;

              return (
                <button
                  key={iso}
                  onClick={() => setSelectedDay(iso)}
                  className={cn(
                    "relative flex aspect-square flex-col items-center justify-center rounded-xl border text-sm transition-all",
                    !inMonth && "opacity-35",
                    isSelected
                      ? "border-primary ring-1 ring-primary"
                      : "border-transparent hover:border-border hover:bg-secondary/50",
                    isToday && !isSelected && "border-primary/40"
                  )}
                >
                  {info && inMonth && intensity > 0 && (
                    <span
                      className="absolute inset-1 rounded-lg"
                      style={{
                        backgroundColor: `hsl(var(--chart-1) / ${0.08 + intensity * 0.22})`,
                      }}
                    />
                  )}
                  <span className="relative tabular font-medium">{format(day, "d")}</span>
                  {info && inMonth && (
                    <span className="relative hidden text-[9px] tabular text-muted-foreground sm:block">
                      {info.expenses > 0 && formatCurrency(info.expenses, currency, { compact: true })}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="mt-4 flex items-center justify-end gap-2 text-xs text-muted-foreground">
            <span>{t("calendar.spent")}</span>
            <div className="flex gap-0.5">
              {[0.2, 0.4, 0.6, 0.8, 1].map((v) => (
                <span
                  key={v}
                  className="size-3 rounded"
                  style={{ backgroundColor: `hsl(var(--chart-1) / ${v})` }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Day detail */}
        <div className="card-premium rounded-2xl p-4">
          {selectedDay && (
            <>
              <div className="mb-3 flex items-center justify-between">
                <h3 className="font-semibold capitalize">
                  {format(parseISO(selectedDay), "EEE, d MMM")}
                </h3>
                {selectedInfo && (
                  <div className="text-end text-xs">
                    {selectedInfo.expenses > 0 && (
                      <p className="font-semibold text-destructive">
                        −{formatCurrency(selectedInfo.expenses, currency)}
                      </p>
                    )}
                    {selectedInfo.income > 0 && (
                      <p className="font-semibold text-positive">
                        +{formatCurrency(selectedInfo.income, currency)}
                      </p>
                    )}
                  </div>
                )}
              </div>
              <AnimatePresence mode="wait">
                {selectedTx.length === 0 ? (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                  >
                    <EmptyState
                      icon="CalendarX"
                      title={t("calendar.noActivity")}
                      className="py-10"
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key={selectedDay}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="space-y-1"
                  >
                    {selectedTx.map((tx) => (
                      <TransactionRow key={tx.id} transaction={tx} />
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          )}
        </div>
      </div>
    </>
  );
}
