"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import {
  User,
  Palette,
  Bell,
  Database,
  ShieldCheck,
  Sun,
  Moon,
  Monitor,
  Download,
  Upload,
  RotateCcw,
  Check,
} from "lucide-react";

import { PageHeader } from "@/components/layout/page-header";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Icon } from "@/components/ui/icon";
import { useStore } from "@/lib/store";
import { useI18n, useLicenseStatus } from "@/lib/hooks";
import { cn } from "@/lib/utils";
import { CURRENCY_LIST } from "@/lib/currencies";
import { describeLicense } from "@/lib/license";
import type { CurrencyCode, DateFormat, Language, Settings } from "@/lib/types";

export default function SettingsPage() {
  const { t } = useI18n();
  const settings = useStore((s) => s.settings);
  const updateSettings = useStore((s) => s.updateSettings);
  const resetData = useStore((s) => s.resetData);
  const deactivate = useStore((s) => s.deactivate);
  const fullState = useStore();
  const { theme, setTheme } = useTheme();
  const license = useLicenseStatus();

  const [saved, setSaved] = React.useState(false);

  const setSetting = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    updateSettings({ [key]: value });
    flashSaved();
  };

  const flashSaved = React.useCallback(() => {
    setSaved(true);
    const t_ = setTimeout(() => setSaved(false), 1500);
    return () => clearTimeout(t_);
  }, []);

  const backup = () => {
    const blob = new Blob([JSON.stringify(fullState, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `spending-tracker-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const restore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string);
        localStorage.setItem("spending-tracker-store", JSON.stringify(data));
        window.location.reload();
      } catch {
        alert("Invalid backup file");
      }
    };
    reader.readAsText(file);
  };

  const exportAll = () => {
    const rows = fullState.transactions.map((tx) => tx);
    const blob = new Blob([JSON.stringify(rows, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "transactions-export.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const themeOptions = [
    { value: "light", icon: Sun, label: t("settings.theme.light") },
    { value: "dark", icon: Moon, label: t("settings.theme.dark") },
    { value: "system", icon: Monitor, label: t("settings.theme.system") },
  ] as const;

  return (
    <>
      <PageHeader title={t("settings.title")} description={t("settings.subtitle")}>
        {saved && (
          <span className="flex items-center gap-1 text-sm font-medium text-positive">
            <Check className="size-4" />
            {t("common.saveChanges")}
          </span>
        )}
      </PageHeader>

      <div className="grid max-w-3xl grid-cols-1 gap-4">
        {/* Profile */}
        <Section icon="User" title={t("settings.profile")}>
          <div className="flex items-center gap-4">
            <div className="flex size-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-primary/70 text-2xl font-bold text-primary-foreground">
              A
            </div>
            <div className="flex-1">
              <p className="font-semibold">Alex Morgan</p>
              <p className="text-sm text-muted-foreground">alex@example.com</p>
            </div>
            <Button variant="outline" size="sm">
              {t("common.edit")}
            </Button>
          </div>
        </Section>

        {/* Preferences */}
        <Section icon="Palette" title={t("settings.preferences")}>
          <Field label={t("settings.theme")}>
            <div className="flex gap-2">
              {themeOptions.map((opt) => {
                const OptIcon = opt.icon;
                return (
                  <button
                    key={opt.value}
                    onClick={() => setTheme(opt.value)}
                    className={cn(
                      "flex flex-1 flex-col items-center gap-1.5 rounded-xl border p-3 text-xs font-medium transition-colors",
                      theme === opt.value
                        ? "border-primary bg-primary/5 text-primary"
                        : "border-border text-muted-foreground hover:bg-secondary"
                    )}
                  >
                    <OptIcon className="size-4" />
                    {opt.label}
                  </button>
                );
              })}
            </div>
          </Field>

          <Field label={t("settings.language")}>
            <Select
              value={settings.language}
              onChange={(e) => setSetting("language", e.target.value as Language)}
            >
              <option value="en">{t("settings.language.en")}</option>
              <option value="ar">{t("settings.language.ar")}</option>
            </Select>
          </Field>

          <Field label={t("settings.currency")}>
            <Select
              value={settings.currency}
              onChange={(e) => setSetting("currency", e.target.value as CurrencyCode)}
            >
              {CURRENCY_LIST.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.symbol} {c.code} — {c.label}
                </option>
              ))}
            </Select>
          </Field>

          <Field label={t("settings.dateFormat")}>
            <Select
              value={settings.dateFormat}
              onChange={(e) => setSetting("dateFormat", e.target.value as DateFormat)}
            >
              <option value="MM/DD/YYYY">MM/DD/YYYY</option>
              <option value="DD/MM/YYYY">DD/MM/YYYY</option>
              <option value="YYYY-MM-DD">YYYY-MM-DD</option>
            </Select>
          </Field>
        </Section>

        {/* Notifications */}
        <Section icon="Bell" title={t("settings.notifications")}>
          <Toggle
            label={t("settings.budgetAlerts")}
            description={t("settings.budgetAlertsDesc")}
            checked={settings.notifications.budgetAlerts}
            onChange={(v) =>
              setSetting("notifications", {
                ...settings.notifications,
                budgetAlerts: v,
              })
            }
          />
          <Toggle
            label={t("settings.recurringReminders")}
            description={t("settings.recurringRemindersDesc")}
            checked={settings.notifications.recurringReminders}
            onChange={(v) =>
              setSetting("notifications", {
                ...settings.notifications,
                recurringReminders: v,
              })
            }
          />
          <Toggle
            label={t("settings.monthlyReport")}
            description={t("settings.monthlyReportDesc")}
            checked={settings.notifications.monthlyReport}
            onChange={(v) =>
              setSetting("notifications", {
                ...settings.notifications,
                monthlyReport: v,
              })
            }
          />
        </Section>

        {/* Data management */}
        <Section icon="Database" title={t("settings.data")}>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={backup}>
              <Download className="size-4" />
              {t("settings.backup")}
            </Button>
            <label>
              <input
                type="file"
                accept="application/json"
                className="hidden"
                onChange={restore}
              />
              <span className="inline-flex h-9 cursor-pointer items-center gap-2 rounded-xl border border-border bg-background/50 px-3 text-xs font-medium transition-colors hover:bg-secondary">
                <Upload className="size-4" />
                {t("settings.restore")}
              </span>
            </label>
            <Button variant="outline" size="sm" onClick={exportAll}>
              <Download className="size-4" />
              {t("settings.exportAll")}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                if (confirm("Reset all data to demo defaults?")) resetData();
              }}
            >
              <RotateCcw className="size-4" />
              Reset
            </Button>
          </div>
        </Section>

        {/* License */}
        <Section icon="KeyRound" title={t("license.manage")}>
          <div className="flex items-center justify-between rounded-xl bg-secondary/60 p-3">
            <div>
              <p className="text-sm font-medium">
                {license.isLicensed
                  ? t("license.active")
                  : license.status === "trial"
                    ? t("license.trialBadge", { days: license.trialDaysLeft })
                    : t("license.title")}
              </p>
              {license.info && (
                <p className="text-xs text-muted-foreground">
                  {describeLicense(license.info)}
                  {license.info.name ? ` · ${license.info.name}` : ""}
                </p>
              )}
            </div>
            {license.isLicensed ? (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (confirm("Deactivate this license on this device?")) deactivate();
                }}
              >
                {t("license.deactivate")}
              </Button>
            ) : (
              <Button asChild variant="gradient" size="sm">
                <a href="/landing">{t("license.buy")}</a>
              </Button>
            )}
          </div>
        </Section>

        {/* Security */}
        <Section icon="ShieldCheck" title={t("settings.security")}>
          <div className="flex items-start gap-3 rounded-xl bg-positive/5 p-3">
            <ShieldCheck className="mt-0.5 size-5 shrink-0 text-positive" />
            <div>
              <p className="text-sm font-medium">{t("settings.security")}</p>
              <p className="text-xs text-muted-foreground">
                {t("settings.securityDesc")}
              </p>
            </div>
          </div>
        </Section>
      </div>
    </>
  );
}

function Section({
  icon,
  title,
  children,
}: {
  icon: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="card-premium rounded-2xl p-5">
      <div className="mb-4 flex items-center gap-2.5">
        <div className="flex size-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Icon name={icon} className="size-4" />
        </div>
        <h2 className="font-semibold">{title}</h2>
      </div>
      <div className="space-y-4">{children}</div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid grid-cols-1 gap-2 sm:grid-cols-[200px_1fr] sm:items-center">
      <Label>{label}</Label>
      <div>{children}</div>
    </div>
  );
}

function Toggle({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-sm font-medium">{label}</p>
        {description && (
          <p className="text-xs text-muted-foreground">{description}</p>
        )}
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cn(
          "relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition-colors",
          checked ? "bg-primary" : "bg-secondary"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 size-5 rounded-full bg-white shadow-soft transition-transform",
            checked ? "translate-x-[22px] rtl:-translate-x-[22px]" : "translate-x-0.5 rtl:-translate-x-0.5"
          )}
        />
      </button>
    </div>
  );
}
