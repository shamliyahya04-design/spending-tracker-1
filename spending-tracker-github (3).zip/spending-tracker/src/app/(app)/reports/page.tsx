"use client";

import * as React from "react";
import {
  endOfWeek,
  format,
  parseISO,
  startOfWeek,
  startOfYear,
  endOfYear,
  subDays,
} from "date-fns";
import { Download, FileText, TrendingUp, TrendingDown, Wallet, PiggyBank } from "lucide-react";

import { PageHeader } from "@/components/layout/page-header";
import { Button } from "@/components/ui/button";
import { Input, Label } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { ChartCard } from "@/components/charts/chart-card";
import { IncomeExpenseChart, CategoryPieChart } from "@/components/charts/lazy";
import { Progress } from "@/components/ui/progress";
import { Icon } from "@/components/ui/icon";
import { useStore } from "@/lib/store";
import { useI18n } from "@/lib/hooks";
import { cn, formatCurrency, exportToCSV, exportToExcel, todayISO } from "@/lib/utils";
import {
  inRange,
  summarize,
  categoryBreakdown,
} from "@/lib/calculations";
import type { CurrencyCode } from "@/lib/types";

type RangeKey = "week" | "month" | "year" | "custom";

export default function ReportsPage() {
  const { t, language } = useI18n();
  const transactions = useStore((s) => s.transactions);
  const categories = useStore((s) => s.categories);
  const currency = useStore((s) => s.settings.currency) as CurrencyCode;

  const now = new Date();
  const [range, setRange] = React.useState<RangeKey>("month");
  const [customStart, setCustomStart] = React.useState(
    format(subDays(now, 30), "yyyy-MM-dd")
  );
  const [customEnd, setCustomEnd] = React.useState(todayISO());

  const { start, end } = React.useMemo(() => {
    const weekStartsOn = language === "ar" ? (6 as const) : (1 as const);
    switch (range) {
      case "week":
        return {
          start: startOfWeek(now, { weekStartsOn }),
          end: endOfWeek(now, { weekStartsOn }),
        };
      case "year":
        return { start: startOfYear(now), end: endOfYear(now) };
      case "custom":
        return { start: parseISO(customStart), end: parseISO(customEnd) };
      default:
        return {
          start: new Date(now.getFullYear(), now.getMonth(), 1),
          end: new Date(now.getFullYear(), now.getMonth() + 1, 0),
        };
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range, customStart, customEnd, language]);

  const scoped = React.useMemo(
    () => inRange(transactions, start, end),
    [transactions, start, end]
  );

  const summary = summarize(scoped);
  const breakdown = React.useMemo(
    () => categoryBreakdown(scoped, categories, currency),
    [scoped, categories, currency]
  );

  // Build monthly buckets within the range for the chart
  const chartData = React.useMemo(() => {
    const buckets: { label: string; income: number; expenses: number }[] = [];
    const months: { start: Date; end: Date; label: string }[] = [];
    let cursor = new Date(start.getFullYear(), start.getMonth(), 1);
    while (cursor <= end) {
      months.push({
        start: new Date(cursor),
        end: new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0),
        label: format(cursor, "MMM"),
      });
      cursor = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1);
    }
    for (const m of months) {
      const s = summarize(inRange(transactions, m.start, m.end));
      buckets.push({ label: m.label, income: s.income, expenses: s.expenses });
    }
    return buckets.length ? buckets : [{ label: format(start, "d MMM"), income: summary.income, expenses: summary.expenses }];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scoped, start, end]);

  const handleExport = (formatType: "csv" | "excel") => {
    const rows = scoped.map((tx) => {
      const cat = categories.find((c) => c.id === tx.categoryId);
      return {
        Date: tx.date,
        Type: tx.type,
        Merchant: tx.merchant,
        Category: cat?.name ?? "",
        Amount: tx.amount,
        Currency: tx.currency,
        Status: tx.status,
      };
    });
    const stamp = `${format(start, "yyyyMMdd")}-${format(end, "yyyyMMdd")}`;
    if (formatType === "csv") exportToCSV(`report-${stamp}.csv`, rows);
    else exportToExcel(`report-${stamp}.xls`, rows);
  };

  const handlePdf = async () => {
    // Lazy-load jsPDF (~140kB) only when the user actually exports a PDF.
    const { generateReportPdf } = await import("@/lib/pdf");
    generateReportPdf({
      title: "Spending Tracker — Report",
      rangeStart: start,
      rangeEnd: end,
      summary: { ...summary, currency },
      transactions: scoped,
      categories,
      formatAmount: (n: number) => formatCurrency(n, currency),
    });
  };

  const stats = [
    {
      label: t("summary.income"),
      value: summary.income,
      icon: TrendingUp,
      tone: "positive" as const,
    },
    {
      label: t("summary.expenses"),
      value: summary.expenses,
      icon: TrendingDown,
      tone: "destructive" as const,
    },
    {
      label: t("reports.netCashFlow"),
      value: summary.balance,
      icon: Wallet,
      tone: summary.balance >= 0 ? ("positive" as const) : ("destructive" as const),
    },
    {
      label: t("summary.savingsRate"),
      value: summary.savingsRate,
      icon: PiggyBank,
      tone: "neutral" as const,
      isRate: true,
    },
  ];

  return (
    <>
      <PageHeader title={t("reports.title")} description={t("reports.subtitle")}>
        <Button variant="outline" size="sm" onClick={() => handleExport("csv")}>
          <Download className="size-4" />
          {t("reports.exportCsv")}
        </Button>
        <Button variant="outline" size="sm" onClick={() => handleExport("excel")}>
          <FileText className="size-4" />
          Excel
        </Button>
        <Button
          variant="gradient"
          size="sm"
          onClick={handlePdf}
          title="PDF export"
        >
          <Download className="size-4" />
          {t("reports.exportPdf")}
        </Button>
      </PageHeader>

      {/* Range controls */}
      <div className="card-premium mb-4 rounded-2xl p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
          <div className="space-y-1.5">
            <Label>{t("reports.range")}</Label>
            <Select
              value={range}
              onChange={(e) => setRange(e.target.value as RangeKey)}
              className="sm:w-44"
            >
              <option value="week">{t("reports.thisWeek")}</option>
              <option value="month">{t("reports.thisMonth")}</option>
              <option value="year">{t("reports.thisYear")}</option>
              <option value="custom">{t("reports.custom")}</option>
            </Select>
          </div>
          {range === "custom" && (
            <div className="flex items-end gap-2">
              <div className="space-y-1.5">
                <Label>{t("reports.from")}</Label>
                <Input
                  type="date"
                  value={customStart}
                  onChange={(e) => setCustomStart(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label>{t("reports.to")}</Label>
                <Input
                  type="date"
                  value={customEnd}
                  onChange={(e) => setCustomEnd(e.target.value)}
                />
              </div>
            </div>
          )}
          <p className="ms-auto self-center text-sm text-muted-foreground">
            {format(start, "d MMM yyyy")} — {format(end, "d MMM yyyy")}
          </p>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((stat, i) => {
          const StatIcon = stat.icon;
          return (
            <div key={i} className="card-premium rounded-2xl p-5">
              <div
                className={cn(
                  "mb-3 flex size-9 items-center justify-center rounded-xl",
                  stat.tone === "positive" && "bg-positive/10 text-positive",
                  stat.tone === "destructive" && "bg-destructive/10 text-destructive",
                  stat.tone === "neutral" && "bg-primary/10 text-primary"
                )}
              >
                <StatIcon className="size-5" />
              </div>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
              <p className="tabular mt-0.5 text-xl font-semibold">
                {stat.isRate
                  ? `${stat.value.toFixed(1)}%`
                  : formatCurrency(stat.value, currency)}
              </p>
            </div>
          );
        })}
      </div>

      {/* Charts */}
      <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard
          title={t("dashboard.incomeVsExpense")}
          description={t("reports.summary")}
          className="lg:col-span-2"
        >
          <IncomeExpenseChart data={chartData} />
        </ChartCard>
        <ChartCard title={t("dashboard.categoryBreakdown")}>
          {breakdown.length === 0 ? (
            <p className="py-12 text-center text-sm text-muted-foreground">
              {t("transactions.empty")}
            </p>
          ) : (
            <CategoryPieChart
              data={breakdown.slice(0, 6).map((b) => ({
                name: b.category.name,
                value: b.total,
                color: b.category.color,
              }))}
            />
          )}
        </ChartCard>
      </div>

      {/* Category breakdown table */}
      <div className="card-premium mt-4 rounded-2xl p-5">
        <h3 className="mb-4 font-semibold">{t("dashboard.topCategories")}</h3>
        <div className="space-y-3">
          {breakdown.slice(0, 8).map((b) => (
            <div key={b.category.id}>
              <div className="mb-1.5 flex items-center justify-between text-sm">
                <span className="flex items-center gap-2">
                  <Icon
                    name={b.category.icon}
                    className="size-4"
                    style={{ color: `hsl(var(--${b.category.color}))` }}
                  />
                  {b.category.name}
                </span>
                <span className="tabular text-muted-foreground">
                  {formatCurrency(b.total, currency)} · {b.percentage.toFixed(0)}%
                </span>
              </div>
              <Progress
                value={b.percentage}
                indicatorClassName="bg-primary"
              />
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
